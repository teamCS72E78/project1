﻿$axure.loadCurrentPage(
(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,c,d,e,f,g,h,g,i,[j,k,l,m,n,o,p],q,_(r,s,t,u,v,w,x,_(),y,_(z,A,B,C,D,_(E,F,G,H),I,null,J,C,K,C,L,M,N,null,O,P,Q,R,S,T,U,P),V,_(),W,_(),X,_(Y,[])),Z,_(),ba,_());}; 
var b="url",c="关于我们.html",d="generationDate",e=new Date(1582281974903.79),f="isCanvasEnabled",g=false,h="isAdaptiveEnabled",i="variables",j="OnLoadVariable",k="tishi",l="username",m="passw",n="NewUsername",o="NewPassw",p="NewPassw2",q="page",r="packageId",s="c34e181afc9e4e0e9d83e0c62229d055",t="type",u="Axure:Page",v="name",w="关于我们",x="notes",y="style",z="baseStyle",A="627587b6038d43cca051c114ac41ad32",B="pageAlignment",C="near",D="fill",E="fillType",F="solid",G="color",H=0xFFFFFFFF,I="image",J="imageHorizontalAlignment",K="imageVerticalAlignment",L="imageRepeat",M="auto",N="favicon",O="sketchFactor",P="0",Q="colorStyle",R="appliedColor",S="fontName",T="Applied Font",U="borderWidth",V="adaptiveStyles",W="interactionMap",X="diagram",Y="objects",Z="masters",ba="objectPaths";
return _creator();
})());